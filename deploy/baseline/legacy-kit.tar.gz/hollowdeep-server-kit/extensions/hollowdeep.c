/*
 * Hollowdeep additions for the original Mordor 3.00 engine.
 * Original engine by Brett Vickers and Brooke Paul; see its copyright notices.
 * Original notices and distribution terms remain with the source package.
 *
 * These commands add a persistent exploration journal and class guidance.
 * Achievement rewards are cosmetic badges, not gold or experience. This
 * avoids changing legacy player structs or creating a second currency ledger.
 * Edit QUESTS below to extend the realm. Keep existing IDs and bit positions
 * stable once characters have earned them. Maximum 16 quests, 128 rooms.
 */
#include "mstruct.h"
#include "hollowdeep.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

extern void print(int fd, const char *format, ...);

#ifndef HOLLOWDEEP_DATA_DIR
#define HOLLOWDEEP_DATA_DIR "hollowdeep-data"
#endif
#define HD_MAX_ROOMS 128
#define HD_PATH_BYTES 512
#define HD_QUEST_COUNT 4
#define HD_ALL_QUESTS ((1U << HD_QUEST_COUNT) - 1)

struct hd_quest {
    const char *id;
    const char *title;
    unsigned int rooms;
    unsigned int level;
    const char *badge;
};

static const struct hd_quest QUESTS[HD_QUEST_COUNT] = {
    {"first-steps", "Beyond the threshold", 3, 1, "Wayfarer"},
    {"mapmaker", "Ten roads remembered", 10, 1, "Pathfinder"},
    {"apprentice", "An adventurer's calling", 3, 3, "Adept"},
    {"veteran", "A name in the chronicles", 10, 5, "Veteran"}
};

struct hd_state {
    unsigned int accepted;
    unsigned int claimed;
    unsigned int room_count;
    unsigned int rooms[HD_MAX_ROOMS];
};

static const char *CLASSES[] = {
    "None", "Assassin", "Barbarian", "Cleric", "Fighter", "Mage",
    "Paladin", "Ranger", "Thief", "Bard", "Monk"
};
static const char *CLASS_GUIDES[] = {
    "Choose a playable class when creating your character.",
    "Work from hiding and choose your opening carefully. Read help backstab and help hide.",
    "A durable melee adventurer. Read help bash and help wield before your next fight.",
    "Faith and healing magic support your journey. Read help cast, help study, and help turn.",
    "A weapon-focused melee adventurer. Read help circle, help bash, and help equipment.",
    "Study magic and manage your mana. Read help cast and help study; choose spells you know.",
    "Combine martial skill and faith. Read help cast, help pray, and help turn.",
    "Read the trail and move with care. Read help track, help sneak, and help search.",
    "Use stealth and a careful opening. Read help hide, help backstab, and help sneak.",
    "An agile adventurer with the original bard charm ability. Read help charm and help cast.",
    "Follow the original martial path. Read help meditate and help touch for your class abilities."
};

/* Character names are an engine field, but still validate before using a path. */
static int state_path(creature *player, char *path, size_t size)
{
    size_t i, length = 0;
    char name[81];
    while (length < sizeof(player->name) && player->name[length]) length++;
    if (length < 2 || length >= sizeof(player->name)) return 0;
    for (i = 0; i < length; i++) {
        unsigned char c = (unsigned char)player->name[i];
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))) return 0;
        name[i] = (char)tolower(c);
    }
    name[length] = '\0';
    return snprintf(path, size, "%s/%s.journal", HOLLOWDEEP_DATA_DIR, name) < (int)size;
}

static int ensure_directory(void)
{
    struct stat st;
    if (lstat(HOLLOWDEEP_DATA_DIR, &st) < 0) {
        if (errno != ENOENT || mkdir(HOLLOWDEEP_DATA_DIR, 0700) < 0) return 0;
        if (lstat(HOLLOWDEEP_DATA_DIR, &st) < 0) return 0;
    }
    return S_ISDIR(st.st_mode) && !S_ISLNK(st.st_mode);
}

/* Return 1 on a valid/new journal; corrupt files are never silently overwritten. */
static int load_state(creature *player, struct hd_state *state)
{
    char path[HD_PATH_BYTES], magic[16], extra;
    unsigned int version, i, j, room_number;
    struct stat st;
    FILE *file;
    int fd;
    memset(state, 0, sizeof(*state));
    if (!state_path(player, path, sizeof(path)) || !ensure_directory()) return 0;
    fd = open(path, O_RDONLY | O_NOFOLLOW);
    if (fd < 0) return errno == ENOENT;
    if (fstat(fd, &st) < 0 || !S_ISREG(st.st_mode) || st.st_size > 4096) { close(fd); return 0; }
    file = fdopen(fd, "r");
    if (!file) { close(fd); return 0; }
    if (fscanf(file, "%15s %u %u %u %u", magic, &version, &state->accepted,
               &state->claimed, &state->room_count) != 5 || strcmp(magic, "HOLLOWDEEP") || version != 1 ||
        state->room_count > HD_MAX_ROOMS || (state->accepted & ~HD_ALL_QUESTS) ||
        (state->claimed & ~HD_ALL_QUESTS) || (state->claimed & ~state->accepted)) { fclose(file); return 0; }
    for (i = 0; i < state->room_count; i++) {
        if (fscanf(file, "%u", &room_number) != 1 || room_number < 1 || room_number > 32767) { fclose(file); return 0; }
        for (j = 0; j < i; j++) if (state->rooms[j] == room_number) { fclose(file); return 0; }
        state->rooms[i] = room_number;
    }
    if (fscanf(file, " %c", &extra) != EOF || ferror(file)) { fclose(file); return 0; }
    return fclose(file) == 0;
}

/* mkstemp + fsync + rename publishes the complete journal in one operation. */
static int save_state(creature *player, const struct hd_state *state)
{
    char path[HD_PATH_BYTES], temporary[HD_PATH_BYTES];
    FILE *file;
    unsigned int i;
    int fd, ok;
    if (!state_path(player, path, sizeof(path)) || !ensure_directory() ||
        snprintf(temporary, sizeof(temporary), "%s/.journal-XXXXXX", HOLLOWDEEP_DATA_DIR) >= (int)sizeof(temporary)) return 0;
    fd = mkstemp(temporary);
    if (fd < 0) return 0;
    file = fdopen(fd, "w");
    if (!file) { close(fd); unlink(temporary); return 0; }
    ok = fprintf(file, "HOLLOWDEEP 1 %u %u %u\n", state->accepted, state->claimed, state->room_count) >= 0;
    for (i = 0; ok && i < state->room_count; i++) ok = fprintf(file, "%u\n", state->rooms[i]) >= 0;
    if (fflush(file) != 0 || fsync(fd) != 0) ok = 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || rename(temporary, path) != 0) { unlink(temporary); return 0; }
    return 1;
}

static void storage_error(creature *player)
{
    print(player->fd, "Your chronicle could not be read or saved. Ask the game host to check hollowdeep-data. No achievement was granted.\n");
}

static int quest_index(const char *id)
{
    int i;
    for (i = 0; i < HD_QUEST_COUNT; i++) if (!strcmp(id, QUESTS[i].id)) return i;
    return -1;
}

int hcommands(creature *player, cmd *command)
{
    (void)command;
    print(player->fd, "HOLLOWDEEP COMMANDS\n");
    print(player->fd, "Explore: look, search, north/south/east/west, up/down, prepare\n");
    print(player->fd, "Fight: kill <creature>, cast <spell> [target], flee\n");
    print(player->fd, "Warning: original Mordor's flee can drop your wielded weapon.\n");
    print(player->fd, "Character: score, equipment, inventory, train, study <scroll>\n");
    print(player->fd, "Together: who, say <message>, tell <name> <message>, follow <name>, group, gtalk <message>\n");
    print(player->fd, "Chronicles: hquest, hquest accept <id>, hquest survey, hquest claim <id>, hprofile\n");
    print(player->fd, "Class guide: hclass [class-name]. Original rules: help <command>.\n");
    return 0;
}

int hclass(creature *player, cmd *command)
{
    int i, selected = (unsigned char)player->class;
    if (command->num > 1) {
        char lower[20]; size_t j;
        selected = -1;
        for (i = 1; i <= 10; i++) {
            for (j = 0; CLASSES[i][j] && j < sizeof(lower)-1; j++) lower[j] = (char)tolower((unsigned char)CLASSES[i][j]);
            lower[j] = '\0';
            if (!strcmp(lower, command->str[1])) selected = i;
        }
    }
    print(player->fd, "Original Mordor classes: assassin, barbarian, cleric, fighter, mage, paladin, ranger, thief, bard, monk.\n");
    if (selected < 1 || selected > 10) { print(player->fd, "Use hclass <class-name> for a playable class guide.\n"); return 0; }
    print(player->fd, "%s: %s\n", CLASSES[selected], CLASS_GUIDES[selected]);
    print(player->fd, "Train in your class's training room when you have enough experience and gold. Class and level restrictions still apply.\n");
    return 0;
}

int hprofile(creature *player, cmd *command)
{
    struct hd_state state;
    int i, badges = 0;
    (void)command;
    if (!load_state(player, &state)) { storage_error(player); return 0; }
    print(player->fd, "HOLLOWDEEP CHRONICLE — %s\n", player->name);
    print(player->fd, "Recorded places: %u. Current character level: %u.\n", state.room_count, (unsigned char)player->level);
    for (i = 0; i < HD_QUEST_COUNT; i++) if (state.claimed & (1U << i)) { print(player->fd, "Badge: %s\n", QUESTS[i].badge); badges++; }
    if (!badges) print(player->fd, "No badges yet. Start with hquest accept first-steps.\n");
    print(player->fd, "Badges are cosmetic journal honors. They do not modify your class, title, gold, or experience.\n");
    return 0;
}

int hquest(creature *player, cmd *command)
{
    struct hd_state state;
    int index, i;
    unsigned int bit, room_number;
    const char *action = command->num > 1 ? command->str[1] : "list";
    if (!load_state(player, &state)) { storage_error(player); return 0; }
    if (!strcmp(action, "survey")) {
        if (!state.accepted) { print(player->fd, "Accept a chronicle first: hquest accept first-steps.\n"); return 0; }
        if (!player->parent_rom || player->parent_rom->rom_num < 1) { print(player->fd, "You cannot survey this location.\n"); return 0; }
        room_number = (unsigned short)player->parent_rom->rom_num;
        for (i = 0; i < (int)state.room_count; i++) if (state.rooms[i] == room_number) { print(player->fd, "This place is already in your chronicle. Explore a new room.\n"); return 0; }
        if (state.room_count == HD_MAX_ROOMS) { print(player->fd, "Your chronicle has recorded its maximum of 128 places.\n"); return 0; }
        state.rooms[state.room_count++] = room_number;
        if (!save_state(player, &state)) { storage_error(player); return 0; }
        print(player->fd, "You record this place in your chronicle. Unique places: %u.\n", state.room_count);
        return 0;
    }
    if (!strcmp(action, "accept") || !strcmp(action, "claim")) {
        if (command->num < 3 || (index = quest_index(command->str[2])) < 0) { print(player->fd, "Choose a quest ID shown by hquest. Example: hquest accept first-steps.\n"); return 0; }
        bit = 1U << index;
        if (!strcmp(action, "accept")) {
            if (state.accepted & bit) { print(player->fd, "That chronicle is already accepted. Use hquest to check it.\n"); return 0; }
            state.accepted |= bit;
            if (!save_state(player, &state)) { storage_error(player); return 0; }
            print(player->fd, "Accepted: %s. Survey %u unique rooms and reach level %u. Earlier surveys count.\n", QUESTS[index].title, QUESTS[index].rooms, QUESTS[index].level);
            return 0;
        }
        if (!(state.accepted & bit)) { print(player->fd, "Accept this chronicle before claiming its badge.\n"); return 0; }
        if (state.claimed & bit) { print(player->fd, "You already earned that badge. Use hprofile to see your honors.\n"); return 0; }
        if (state.room_count < QUESTS[index].rooms || (unsigned char)player->level < QUESTS[index].level) {
            print(player->fd, "Not complete: %u/%u places; level %u/%u.\n", state.room_count, QUESTS[index].rooms, (unsigned char)player->level, QUESTS[index].level); return 0;
        }
        state.claimed |= bit;
        if (!save_state(player, &state)) { storage_error(player); return 0; }
        print(player->fd, "Chronicle complete: %s. You earned the %s badge!\n", QUESTS[index].title, QUESTS[index].badge);
        return 0;
    }
    if (strcmp(action, "list") && strcmp(action, "status")) {
        print(player->fd, "Usage: hquest [list|status|survey|accept <id>|claim <id>]\n"); return 0;
    }
    print(player->fd, "THE HOLLOWDEEP CHRONICLES\nRecord real places with hquest survey. Each room counts once.\n");
    for (i = 0; i < HD_QUEST_COUNT; i++) {
        bit = 1U << i;
        print(player->fd, "%s — %s [%s]\n", QUESTS[i].id, QUESTS[i].title,
              (state.claimed & bit) ? "claimed" : (state.accepted & bit) ? "active" : "available");
        print(player->fd, "  Places %u/%u; level %u/%u. Badge: %s.\n", state.room_count, QUESTS[i].rooms,
              (unsigned char)player->level, QUESTS[i].level, QUESTS[i].badge);
    }
    print(player->fd, "hquest accept <id> | hquest survey | hquest claim <id> | hprofile\n");
    return 0;
}
