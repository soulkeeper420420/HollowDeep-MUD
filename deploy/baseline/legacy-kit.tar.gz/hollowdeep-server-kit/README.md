# Hollowdeep server development kit

An editable extension kit for the **original Mordor 3.00** by Brett Vickers and Brooke Paul. This is the original native C engine, with compatibility adjustments and optional Hollowdeep exploration commands. The browser client remains at https://hollowdeep-dungeon.soulkeeper420.chatgpt.site/.

## What is included

- `manage.py`: checksum-verified source preparation, a 32-bit build, explicit extension synchronization, and a foreground development launcher.
- `extensions/hollowdeep.c`: four actual C commands and four persistent exploration chronicles.
- `extensions/hollowdeep_net.c`: per-connection Telnet and line-ending normalization for native and browser clients.
- `extensions/help.84` through `help.87`: the added in-game help pages.
- `tests/`: native extension behavior tests and source preparation checks.
- `bridge/` in the download: the Node.js WebSocket-to-Telnet bridge, including its dependency lockfile.
- Original copyright and disclaimer notices. The downloadable kit also includes the unmodified `Mordor_3.00.tar.gz` distribution.

The original ten classes, combat, spells, world and player-file format remain in Mordor. Atlas inspired the emphasis on class guidance, exploration, party tools and an accessible help library. This kit does not copy Atlas content or implement its remort classes, player housing or shop ownership.

## Requirements and verification

Use Linux with Python 3, Make and a **32-bit-capable GCC toolchain**. On Debian/Ubuntu this normally means `build-essential`, `gcc-multilib` and `libc6-dev-i386`. Ask a shared hosting provider to supply these; root access is not required by the toolkit itself. An x86 Linux host is the simplest target.

On a Debian/Ubuntu host you administer, install the prerequisites with:

```sh
sudo apt-get update
sudo apt-get install python3 build-essential gcc-multilib libc6-dev-i386
```

The original world files serialize native C structures. A normal 64-bit executable is incompatible with that data, so the build refuses to proceed without a working 32-bit compiler and runtime. Do not remove `-m32` to bypass this check.

The original engine compiles and links as a 32-bit ELF executable using GCC 14. The ABI check runs under QEMU i386 in this workspace. The C extensions pass 46 behavioral assertions, the input normalizer passes 1,052 assertions, and Mordor's actual input routine passes 23 integration assertions using pipes. Both input suites pass with 32-bit GCC/QEMU. **Live multiplayer gameplay remains unverified here** because local socket access is restricted; run the runtime smoke test on your host before opening the game to players.

Connection compatibility fixes handle CRLF and CR-NUL split across TCP reads, remove Telnet negotiation from player input, preserve prompts during negotiation-only reads, and keep password echo disabled during character creation. Preparation also corrects the original weather-array declaration and oversized lockout-message writes for modern compilers.

## Prepare, build and play locally

Extract the downloadable kit, open a terminal in `hollowdeep-server-kit`, then run:

```sh
python3 manage.py prepare --archive Mordor_3.00.tar.gz --destination ../hollowdeep-world --admin Realmkeeper
python3 manage.py build --work ../hollowdeep-world
python3 manage.py run --work ../hollowdeep-world --port 4040
```

If the compiler can link 32-bit programs but the host cannot execute them directly, install `qemu-user` and add `--runner /usr/bin/qemu-i386` to both `build` and `run`. This is optional; ordinary x86 Linux hosts with i386 execution support can use the commands above. A compiler installed outside the system paths can be selected with `build --cc /path/to/compiler-wrapper`.

Choose your own administrative character name in place of `Realmkeeper` (3–14 letters, initial capital). Preparation refuses to overwrite an existing destination. It preserves the original notices, imports the original world and source, excludes distributed player accounts and old executable files, and configures only your chosen administrative name. Source changes are recorded in `hollowdeep-compatibility.patch`.

Connect a MUD client to `127.0.0.1`, port `4040`, and create the configured administrator locally before permitting public connections. Native clients use Mordor's character login; browser ChatGPT sign-in does not grant game administrator powers.

If you have the source checkout rather than the downloadable bundle, fetch the pinned archive first:

```sh
python3 manage.py fetch --output Mordor_3.00.tar.gz
```

## Code the server and apply workshop changes

Open `/workshop` on the Hollowdeep site and choose **Load server kit**. Edit `extensions/hollowdeep.c` to change quest thresholds, class guidance or command behavior. Save a local draft and export a patch. Downloading the whole workshop JSON preserves original versions for future patches.

From the matching kit directory, apply your exported patch and sync the edited extensions into your prepared world:

```sh
git apply --check /path/to/hollowdeep-server.patch
git apply /path/to/hollowdeep-server.patch
python3 manage.py sync-extensions --work ../hollowdeep-world
python3 manage.py build --work ../hollowdeep-world
```

`sync-extensions` keeps backups of replaced files. It does not restart a running server. Save and quit test characters, stop the development process, and start the rebuilt engine again. If you edit files directly in `hollowdeep-world/src_3.00`, use `build` without synchronization; synchronization explicitly replaces the eight extension files with the kit copies. Older prepared checkouts without the connection fixes require a separate fresh preparation with this kit; keep the old world and player saves intact while validating the new checkout.

For broader engine changes, open the prepared `src_3.00` directory in your preferred code editor or import selected files into the browser workshop. Command registration is in `global.c`; player and room types are in `mstruct.h`; constants and class IDs are in `mtype.h`. `manage.py` documents each compatibility edit. When adding a new C file, register its handler and add its object to the prepared Makefile.

## Chronicle commands

| Command | Behavior |
| --- | --- |
| `hcommands` | Added commands and useful original game commands. |
| `hclass` / `hclass mage` | Guidance for your current class or a named original class. |
| `hquest` | List available, active and claimed chronicles. |
| `hquest accept first-steps` | Accept a chronicle. Other IDs: `mapmaker`, `apprentice`, `veteran`. |
| `hquest survey` | Record the character's actual current room once. |
| `hquest claim first-steps` | Claim the completed chronicle's badge. |
| `hprofile` | Show recorded places and earned badges. |

First Steps needs 3 rooms; Mapmaker needs 10; Apprentice needs 3 rooms and level 3; Veteran needs 10 rooms and level 5. Earlier surveys count toward accepted chronicles. Rewards are cosmetic badges, not gold or experience. State is stored per character under `hollowdeep-data/`, separate from the original player structure. Keep quest IDs and bit positions stable after players begin earning them.

## Test and publish on a MUD host

```sh
python3 tests/test_extensions.py --source ../hollowdeep-world/src_3.00
python3 tests/test_network.py --source ../hollowdeep-world/src_3.00
python3 tests/test_input.py --source ../hollowdeep-world/src_3.00
python3 tests/test_runtime.py --archive Mordor_3.00.tar.gz
```

The runtime smoke test creates and removes its own disposable world, builds the original engine, and connects two local players. It checks character creation, world loading, chat, parties, Chronicle commands and persistence across a server restart. It accepts the same optional `--cc` and `--runner` settings as `build`. It never connects to an existing game or uses your real player saves.

Before public launch, test character creation/login, saving and reloading, movement, combat, training, party chat and every added chronicle with two client connections. Verify that the original world data reads correctly on the host. Back up `player/`, `hollowdeep-data/`, world files and local changes before replacing an existing installation.

Once the host allocates a public TCP port and your administrator exists:

```sh
python3 manage.py run --work ../hollowdeep-world --port 4040 --public
```

Use the host-assigned port in place of 4040. Run under the host's approved process supervisor for persistent service. The launcher binds loopback unless `--public` is supplied; it does not configure a firewall or provide hosting. Public-mode checks require your configured administrator's player file to exist.

The published browser interface also needs the Node.js 22 WebSocket bridge included in the kit's `bridge/` directory (the site's source calls it `server/`). Run `npm ci` in that directory. Configure `MORDOR_HOST=127.0.0.1`, the engine's `MORDOR_PORT`, the bridge HTTP `PORT`, and `ALLOWED_ORIGINS=https://hollowdeep-dungeon.soulkeeper420.chatgpt.site`. Generate a random secret of at least 32 bytes on your host and set it as `BRIDGE_SECRET`; set the same secret in Sites runtime settings. Start the bridge with `npm start` and supply TLS termination so `/socket` is available over `wss://`. Configure Sites with `BRIDGE_URL`, `BRIDGE_SECRET`, `MUD_PUBLIC_HOST`, and `MUD_PUBLIC_PORT`. Request the bridge and TLS routing explicitly from Mudhaven. Keep unsigned development access disabled for public hosting. Never put a bridge secret, player save, or password in the browser workshop.

## License

Keep the original Mordor copyright and credits unchanged. Its authors permit free-of-charge use under the included COPYRIGHT terms; commercial use requires their permission. This kit grants no additional rights to their engine or to Atlas. No hosting application, game-host deployment or live restart is performed by these tools.
