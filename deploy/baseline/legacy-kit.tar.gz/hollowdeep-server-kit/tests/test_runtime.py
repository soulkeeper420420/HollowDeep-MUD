#!/usr/bin/env python3
"""Build and smoke-test original Mordor in a new, disposable localhost world.

Requires Linux and a working 32-bit compiler/runtime. This never connects to an
existing game or accepts a world path. All players, credentials and saves are
temporary. Example:
  python3 tests/test_runtime.py --archive Mordor_3.00.tar.gz --cc gcc
"""
import argparse
import importlib.util
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[1]
PROMPT = re.compile(r'\(-?\d+ H -?\d+ M\): ')
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
TIMEOUT = 12


class SmokeFailure(Exception):
    pass


class Client:
    """Small incremental Telnet reader; sends only ordinary test input lines."""
    def __init__(self, connection, process, passwords):
        self.connection = connection
        self.process = process
        self.passwords = passwords
        self.pending = ''
        self.telnet = 'text'
        self.telnet_command = 0
        self.echo = True
        self.connection.settimeout(0.2)

    def close(self):
        self.connection.close()

    def clean(self, data):
        output = bytearray()
        for byte in data:
            if self.telnet == 'text':
                if byte == 255:
                    self.telnet = 'iac'
                else:
                    output.append(byte)
            elif self.telnet == 'iac':
                if byte == 255:
                    output.append(byte)
                    self.telnet = 'text'
                elif byte in (251, 252, 253, 254):
                    self.telnet_command = byte
                    self.telnet = 'option'
                elif byte == 250:
                    self.telnet = 'subnegotiation'
                else:
                    self.telnet = 'text'
            elif self.telnet == 'option':
                if byte == 1 and self.telnet_command in (251, 252):
                    self.echo = self.telnet_command == 252
                    reply = 254 if self.echo else 253
                    self.connection.sendall(bytes([255, reply, 1]))
                self.telnet = 'text'
            elif self.telnet == 'subnegotiation' and byte == 255:
                self.telnet = 'subnegotiation-iac'
            elif self.telnet == 'subnegotiation-iac':
                self.telnet = 'text' if byte == 240 else 'subnegotiation'
        return output.decode('latin-1').replace('\r', '')

    def read_until(self, expected, *, prompt=False, label='server response'):
        deadline = time.monotonic() + TIMEOUT
        expected = (expected,) if isinstance(expected, str) else tuple(expected)
        while True:
            visible = ANSI.sub('', self.pending)
            ends = [visible.find(token) + len(token) for token in expected
                    if token in visible]
            if len(ends) == len(expected):
                end = max(ends, default=0)
                match = PROMPT.search(visible, end) if prompt else None
                if not prompt or match:
                    end = match.end() if match else end
                    result, self.pending = visible[:end], visible[end:]
                    return result
            if self.process.poll() is not None:
                raise SmokeFailure(f'{label}: engine exited with {self.process.returncode}')
            if time.monotonic() >= deadline:
                excerpt = visible[-700:]
                for password in self.passwords:
                    excerpt = excerpt.replace(password, '[redacted]')
                raise SmokeFailure(f'{label}: timed out waiting for {expected!r}; received {excerpt!r}')
            try:
                data = self.connection.recv(8192)
            except socket.timeout:
                continue
            if not data:
                raise SmokeFailure(f'{label}: connection closed unexpectedly')
            self.pending += self.clean(data)
            if len(self.pending) > 128 * 1024:
                raise SmokeFailure(f'{label}: excessive server output')

    def send(self, line):
        self.connection.sendall(line.encode('ascii') + b'\r\n')

    def command(self, line, expected):
        self.send(line)
        return self.read_until(expected, prompt=True, label=line)

    def create(self, name, password):
        self.read_until('Please enter name: ', label='new connection')
        # Printable option IDs and TTYPE payloads must never prefix a name.
        self.connection.sendall(bytes([255, 253, 86, 255, 250, 24, 0]) +
                                b'MUDLET' + bytes([255, 240]))
        steps = [
            (name, 'Did I get that right? '),
            ('y', 'Hit return: '),
            ('', 'Male or Female: '),
            ('m', 'Choose one: '),
            ('fighter', 'Use the following format: ## ## ## ## ##\n: '),
            ('14 10 12 10 8', 'Sharp, Thrusting, Blunt, Pole, Missile.\n: '),
            ('sharp', 'Chaotic or Lawful: '),
            ('lawful', 'Choose one: '),
            ('human', 'Choose a password (up to 14 chars): '),
        ]
        for number, (line, expected) in enumerate(steps, 1):
            self.send(line)
            self.read_until(expected, label=f'create {name}, step {number}')
        if self.echo:
            raise SmokeFailure('new character password prompt did not disable client echo')
        self.send(password)
        self.read_until("Type 'welcome'", prompt=True, label=f'finish creating {name}')
        if not self.echo:
            raise SmokeFailure('client echo was not restored after character creation')

    def login(self, name, password):
        self.read_until('Please enter name: ', label='reconnect')
        self.connection.sendall(name.encode('ascii') + b'\r')
        self.read_until('Please enter password: ', label='existing character login')
        if self.echo:
            raise SmokeFailure('existing character password prompt did not disable client echo')
        # The password prompt proves the first CR was processed by read(). The
        # following LF must be consumed, not submitted as an empty password.
        self.connection.sendall(b'\n')
        self.send(password)
        self.read_until('Hollowdeep: original Mordor 3.00', prompt=True,
                        label='finish existing character login')
        if not self.echo:
            raise SmokeFailure('client echo was not restored after successful login')

    def quit(self):
        self.send('quit')
        self.read_until('Goodbye!', label='save and quit')
        self.close()


def stop(process):
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


def available_port(requested):
    # Refuse an occupied explicit port before starting or connecting to anything.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(('127.0.0.1', requested or 0))
        return probe.getsockname()[1]


def connect(port, process, passwords):
    deadline = time.monotonic() + TIMEOUT
    while process.poll() is None and time.monotonic() < deadline:
        try:
            connection = socket.create_connection(('127.0.0.1', port), timeout=0.2)
            return Client(connection, process, passwords)
        except (ConnectionRefusedError, TimeoutError):
            time.sleep(0.05)
    raise SmokeFailure(f'engine did not open its localhost listener (exit={process.poll()})')


def run(args):
    spec = importlib.util.spec_from_file_location('hollowdeep_manage', ROOT / 'manage.py')
    manage = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(manage)
    passwords = [secrets.token_hex(6), secrets.token_hex(6)]
    clients, process = [], None
    with tempfile.TemporaryDirectory(prefix='hollowdeep-runtime-') as temporary:
        base = Path(temporary)
        world = manage.prepare_archive(args.archive.resolve(), base / 'world', 'Realmkeeper')
        build_command = [sys.executable, str(ROOT / 'manage.py'), 'build', '--work', str(world), '--cc', args.cc]
        if args.runner:
            build_command.extend(['--runner', args.runner])
        build = subprocess.run(
            build_command,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=240)
        if build.returncode:
            raise SmokeFailure('32-bit engine build failed:\n' + build.stdout[-8000:])
        executable = world / manage.SOURCE_DIR / 'frp.new'
        if executable.read_bytes()[:5] != b'\x7fELF\x01':
            raise SmokeFailure('engine is not a 32-bit ELF executable')
        print('PASS: prepared and linked original engine as ELF32', flush=True)
        port = available_port(args.port)
        log_path = base / 'engine.log'
        try:
            with log_path.open('ab') as log:
                def launch():
                    environment = os.environ.copy()
                    environment['HOLLOWDEEP_BIND'] = '127.0.0.1'
                    command = ([args.runner] if args.runner else []) + [str(executable), str(port), '-r']
                    return subprocess.Popen(command, cwd=world,
                                            env=environment, stdin=subprocess.DEVNULL,
                                            stdout=log, stderr=subprocess.STDOUT)

                process = launch()
                hero = connect(port, process, passwords)
                clients.append(hero)
                hero.create('Smokehero', passwords[0])
                hero.command('look', 'The Tree of Life')
                hero.command('score', ('Smokehero', '(level 1)'))
                hero.command('hcommands', 'HOLLOWDEEP COMMANDS')
                hero.command('hclass', 'Fighter:')
                hero.command('hclass mage', 'Mage:')
                print('PASS: character creation, world loading, class and command guides', flush=True)

                friend = connect(port, process, passwords)
                clients.append(friend)
                friend.create('Smokefriend', passwords[1])
                hero.command('who', ('Smokehero', 'Smokefriend'))
                hero.command('say hello companion', 'Ok.')
                friend.read_until('hello companion.', prompt=True, label='room chat delivery')
                hero.command('tell Smokefriend private greeting', 'Message sent to Smokefriend.')
                friend.read_until('private greeting', prompt=True, label='private message delivery')
                friend.command('follow Smokehero', 'You start following Smokehero.')
                hero.command('group', ('People in your group:', 'Smokefriend'))
                hero.command('gtalk party greeting', 'party greeting')
                friend.read_until('party greeting', prompt=True, label='group message delivery')
                friend.command('follow Smokefriend', 'You stop following Smokehero.')
                friend.quit()
                print('PASS: two simultaneous players, who, say, tell, follow, group and gtalk', flush=True)

                hero.command('hquest', 'THE HOLLOWDEEP CHRONICLES')
                hero.command('hquest accept first-steps', 'Accepted: Beyond the threshold.')
                hero.command('hquest survey', 'Unique places: 1.')
                hero.command('hquest survey', 'This place is already in your chronicle.')
                hero.command('hquest claim first-steps', 'Not complete: 1/3 places; level 1/1.')
                hero.command('down', 'The Tree of Life')
                hero.command('hquest survey', 'Unique places: 2.')
                # Room 1784 has an unrestricted north exit to room 1724.
                hero.send('north')
                hero.read_until((), prompt=True, label='move north')
                hero.command('hquest survey', 'Unique places: 3.')
                hero.command('hquest claim first-steps', 'You earned the Wayfarer badge!')
                hero.command('hquest claim first-steps', 'You already earned that badge.')
                hero.command('hprofile', ('Recorded places: 3.', 'Badge: Wayfarer'))
                hero.command('save', 'Player saved.')
                hero.quit()
                print('PASS: movement, unique surveys, early/repeated claim guards and earned badge', flush=True)

                # A process restart ensures persistence is not just in-memory state.
                stop(process)
                process = launch()
                hero = connect(port, process, passwords)
                clients.append(hero)
                hero.login('Smokehero', passwords[0])
                hero.command('score', ('Smokehero', '(level 1)'))
                hero.command('hclass', 'Fighter:')
                hero.command('hprofile', ('Recorded places: 3.', 'Badge: Wayfarer'))
                hero.command('hquest', 'first-steps')
                hero.command('hquest claim first-steps', 'You already earned that badge.')
                hero.quit()
                print('PASS: saved character and chronicle survive engine restart and login', flush=True)
        except (SmokeFailure, OSError) as error:
            log_tail = log_path.read_text(errors='replace')[-4000:] if log_path.exists() else ''
            detail = str(error) + ('\nEngine log:\n' + log_tail if log_tail else '')
            for password in passwords:
                detail = detail.replace(password, '[redacted]')
            raise SmokeFailure(detail) from None
        finally:
            for client in clients:
                client.close()
            stop(process)
    print('Native runtime smoke test passed; disposable world removed.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True,
                        help='Unmodified checksum-pinned Mordor_3.00.tar.gz')
    parser.add_argument('--cc', default=os.environ.get('CC', 'cc'),
                        help='Compiler executable or wrapper path (default: CC or cc)')
    parser.add_argument('--runner', help='Single executable such as qemu-i386 for running ELF32')
    parser.add_argument('--port', type=int, help='Unused localhost TCP port; default: select one')
    args = parser.parse_args()
    if args.port is not None and not 1024 <= args.port <= 65535:
        parser.error('--port must be between 1024 and 65535')
    try:
        run(args)
    except (SmokeFailure, ValueError, OSError, subprocess.SubprocessError) as error:
        print(f'FAIL: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
