/* Integration harness: compile the real extension against original engine types. */
#include "mstruct.h"
#include "hollowdeep.h"
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>

static char output[16000];
static int checks;
void print(int fd, const char *format, ...)
{
    va_list args;
    size_t used = strlen(output);
    (void)fd;
    va_start(args, format);
    vsnprintf(output + used, sizeof(output) - used, format, args);
    va_end(args);
}
static void contains(const char *text)
{
    if (!strstr(output, text)) { fprintf(stderr, "Expected %s in:\n%s\n", text, output); exit(1); }
    checks++;
}
static void quest(creature *player, const char *words)
{
    cmd command;
    char copy[256], *part;
    memset(&command, 0, sizeof(command));
    snprintf(copy, sizeof(copy), "%s", words);
    part = strtok(copy, " ");
    while (part && command.num < COMMANDMAX) {
        snprintf(command.str[command.num++], sizeof(command.str[0]), "%s", part);
        part = strtok(NULL, " ");
    }
    output[0] = '\0';
    hquest(player, &command);
}
int main(int argc, char **argv)
{
    creature player;
    room location;
    cmd command;
    FILE *file;
    int i;
    assert(argc == 2 && chdir(argv[1]) == 0);
    memset(&player, 0, sizeof(player)); memset(&location, 0, sizeof(location)); memset(&command, 0, sizeof(command));
    strcpy(player.name, "Tester"); player.level = 1; player.class = FIGHTER; player.fd = 1; player.parent_rom = &location;
    player.gold = 123; player.experience = 456;

    quest(&player, "hquest survey"); contains("Accept a chronicle first");
    quest(&player, "hquest claim first-steps"); contains("Accept this chronicle");
    quest(&player, "hquest accept first-steps"); contains("Accepted:");
    quest(&player, "hquest claim first-steps"); contains("Not complete");
    for (i = 1; i <= 3; i++) { location.rom_num = i; quest(&player, "hquest survey"); contains("Unique places:"); }
    quest(&player, "hquest survey"); contains("already in your chronicle");
    location.rom_num = 0; quest(&player, "hquest survey"); contains("cannot survey"); location.rom_num = 3;
    quest(&player, "hquest claim first-steps"); contains("Wayfarer badge");
    quest(&player, "hquest claim first-steps"); contains("already earned");
    output[0] = '\0'; hprofile(&player, &command); contains("Badge: Wayfarer"); contains("Recorded places: 3");
    strcpy(player.name, "Second"); output[0] = '\0'; hprofile(&player, &command); contains("No badges yet"); contains("Recorded places: 0"); strcpy(player.name, "Tester");
    assert(player.gold == 123 && player.experience == 456); checks++;
    quest(&player, "hquest accept apprentice"); contains("Accepted:");
    quest(&player, "hquest claim apprentice"); contains("Not complete");
    player.level = 3;
    quest(&player, "hquest claim apprentice"); contains("Adept badge");
    quest(&player, "hquest accept mapmaker"); contains("Accepted:");
    for (i = 4; i <= 10; i++) { location.rom_num = i; quest(&player, "hquest survey"); contains("Unique places:"); }
    quest(&player, "hquest claim mapmaker"); contains("Pathfinder badge");
    quest(&player, "hquest accept veteran"); contains("Accepted:");
    quest(&player, "hquest claim veteran"); contains("Not complete");
    player.level = 5;
    quest(&player, "hquest claim veteran"); contains("Veteran badge");
    quest(&player, "hquest status"); contains("first-steps"); contains("[claimed]");

    /* Restart-style access: a fresh creature uses the journal on disk. */
    memset(&player, 0, sizeof(player)); strcpy(player.name, "Tester"); player.level = 5; player.class = MAGE;
    quest(&player, "hquest claim veteran"); contains("already earned");
    quest(&player, "hquest accept missing"); contains("Choose a quest ID");
    quest(&player, "hquest survey"); contains("cannot survey");
    output[0] = '\0'; hclass(&player, &command); contains("Mage:"); contains("enough experience and gold");
    output[0] = '\0'; hcommands(&player, &command); contains("hquest"); contains("flee can drop");

    /* Bad journals are rejected, and symlinks are never followed. */
    file = fopen("hollowdeep-data/tester.journal", "w"); assert(file); fputs("HOLLOWDEEP 1 1 1 2\n1\n1\n", file); fclose(file);
    quest(&player, "hquest survey"); contains("could not be read or saved");
    file = fopen("hollowdeep-data/tester.journal", "r"); assert(file); { char buffer[80]; assert(fgets(buffer, sizeof(buffer), file)); assert(strstr(buffer, "1 1 1 2")); } fclose(file); checks++;
    assert(unlink("hollowdeep-data/tester.journal") == 0);
    file = fopen("outside", "w"); assert(file); fputs("unchanged", file); fclose(file);
    assert(symlink("../outside", "hollowdeep-data/tester.journal") == 0);
    quest(&player, "hquest accept first-steps"); contains("could not be read or saved");
    file = fopen("outside", "r"); assert(file); { char buffer[30]; assert(fgets(buffer, sizeof(buffer), file)); assert(!strcmp(buffer, "unchanged")); } fclose(file); checks++;
    strcpy(player.name, "../outside"); quest(&player, "hquest accept first-steps"); contains("could not be read or saved");
    memset(player.name, 'A', sizeof(player.name)); quest(&player, "hquest"); contains("could not be read or saved");
    printf("%d extension behavior checks passed.\n", checks);
    return 0;
}
